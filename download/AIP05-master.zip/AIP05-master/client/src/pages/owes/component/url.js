

export const UPLOAD_URL = 'https://api.cloudinary.com/v1_1/da6ubhl1q/image/upload';
export const UPLOAD_PRESET = 'myuploadpreset';