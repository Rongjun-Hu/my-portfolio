The live version of this app can be viewed at https://asd-demo-app-g11.herokuapp.com/

If you would like to run this version locally on LINUX, run start.sh in a linux terminal.
For example, open the terminal in linux, navigate to this folder using the "cd" command then run "sh start.sh"

If you would like to run this version locally on WINDOWS, install Node.js from https://nodejs.org/en/download/ then run start.cmd
If Windows needs to download some dependencies, wait a few minutes for it to download these dependencies before running it again.

The app should then be viewable at http://localhost:3000/