//we are using the Express framework for Node.js
const express = require('express');
const app = express();
const nodemailer = require('nodemailer');
const database = require('./database.js')
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended : false}));

var emailSender = nodemailer.createTransport({
   service: 'sendgrid',
   auth: {
     user: 'apikey',
     pass: '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'
   }
 });
async function sendStockAlert(employeeID){
   let thisEmployee = await database.findEmployee(employeeID)
   var emailRecipient = thisEmployee.employee_email
   var emailMessage = 'This report was automatically generated at ' + Date() + '\n'
   let lowStockItems = await database.lowStock()
   let noStockItems = await database.noStock()
   let expiringItems = await database.expiringStock()
   var emailMessage = emailMessage + '\nThe following items are low on stock:'
   for(var i=0; i < lowStockItems.length; i++) {
    emailMessage = emailMessage + "\n" + lowStockItems[i].product_name + " - " + lowStockItems[i].product_quantity + " remaining."
   }
   var emailMessage = emailMessage + ' \n \nThe following items are out of stock:'
   for(var i=0; i < noStockItems.length; i++) {
    emailMessage = emailMessage + "\n" + noStockItems[i].product_name + " - Out of Stock"
   }
   var emailMessage = emailMessage + ' \n \nThe following items are expiring in the next week:'
   for(var i=0; i < expiringItems.length; i++) {
    emailMessage = emailMessage + "\n" + expiringItems[i].product_quantity + " x " + expiringItems[i].product_name + " - expiring on " + expiringItems[i].product_expirydate
   }

   var emailDetails = {
      from: 'asd.group.11.mon@gmail.com',
      to: emailRecipient,
      subject: 'Warehouse Management Solutions - Report',
      text: emailMessage
    };

   emailSender.sendMail(emailDetails, function(error, info){
      if (error) {
      console.log(error);
      } else {
      console.log('Report sent to ' + emailRecipient);
}})}



async function sendShipmentAlert(employeeID){
  let thisEmployee = await database.findEmployee(employeeID)
  var emailRecipient = thisEmployee.employee_email
  var emailMessage = 'This report was automatically generated at ' + Date() + '\n'
  let shipments = await database.shipmentsToday()
  var emailMessage = emailMessage + '\nThe following shipments were recently dispatched:'
  for(var i=0; i < shipments.length; i++) {
    let shippingEmployee = await database.findEmployee(shipments[i].employee_id)
    emailMessage = emailMessage + "\nID: " + shipments[i].shipment_id + "\nShipment size: " + shipments[i].shipment_quantity + "\nShipment dispatched by: " + shippingEmployee.employee_name
  }
  var emailDetails = {
     from: 'asd.group.11.mon@gmail.com',
     to: emailRecipient,
     subject: 'Warehouse Management Solutions - Report',
     text: emailMessage
   };

  emailSender.sendMail(emailDetails, function(error, info){
     if (error) {
     console.log(error);
     } else {
     console.log('Report sent to ' + emailRecipient);
}})}

module.exports = {sendStockAlert, sendShipmentAlert}