//we are using the Express framework for Node.js
const express = require('express');
const app = express();
var database = require('./database.js')
var bodyParser = require('body-parser');
var alerts = require('./alerts.js')
app.use(bodyParser.urlencoded({extended : false}));
app.use('/css', express.static('css'));

// start the server locally on port 3000
app.listen(process.env.PORT || 3000,
   () => console.log("Server running. If running locally, open http://localhost:3000/ to view."));
var employeeID = null
var employeePassword = null
var sessionEmployeeID = ""
var currentName = ""
// Login page when you first open the system
function indexHandler(request, response) {
   employeeID = null
   employeePassword = null
   response.render(__dirname + '/pages/login.ejs', {errorMessage: ""});
   }

async function control_panelHandler(request, response) {
   if (currentName != ""){
      response.render(__dirname + '/pages/control_panel.ejs', {currentName: currentName})
   }
   else {
      response.render(__dirname + '/pages/login.ejs', {errorMessage: ""});
   }
   }

async function shipment_managementHandler(request, response) {
   let data = await database.viewShipments()
   response.render(__dirname + '/pages/shipment_management.ejs', {data: data});
   }
async function customer_managementHandler(request, response) {
   let data = await database.viewCustomers()
   response.render(__dirname + '/pages/customer_management.ejs', {data: data});
   }
async function stock_managementHandler(request, response) {
   let data = await database.viewProducts()
   response.render(__dirname + '/pages/stock_management.ejs', {data: data});
   }
async function order_managementHandler(request, response) {
   let data = await database.viewOrders()
   response.render(__dirname + '/pages/order_management.ejs', {data: data});
   }
async function user_managementHandler(request, response) {
   let data = await database.viewEmployees()
   response.render(__dirname + '/pages/user_management.ejs', {data: data});
   }
function stock_tracking_systemHandler(request, response) {
   response.render(__dirname + '/pages/stock_tracking.ejs', {alertMessage: ""});
   }
function stock_tracking_system_reportHandler(request, response) {
   alerts.sendStockAlert(sessionEmployeeID)
   response.render(__dirname + '/pages/stock_tracking.ejs', {alertMessage: "Report sent to your email address."});
   }
function stock_tracking_system_yesHandler(request, response) {
   response.render(__dirname + '/pages/stock_tracking.ejs', {alertMessage: "Preference updated. Receiving daily stock and expiry alerts."});
   }
function stock_tracking_system_noHandler(request, response) {
   response.render(__dirname + '/pages/stock_tracking.ejs', {alertMessage: "Preference updated. Stopped receiving daily stock and expiry alerts."});
   }
function order_tracking_system_reportHandler(request, response) {
   alerts.sendShipmentAlert(sessionEmployeeID)
   response.render(__dirname + '/pages/stock_tracking.ejs', {alertMessage: "Report sent to your email address."});
   }
function order_tracking_systemHandler(request, response) {
   response.render(__dirname + '/pages/order_tracking.ejs', {alertMessage: ""});
   }
function order_tracking_system_noHandler(request, response) {
   response.render(__dirname + '/pages/order_tracking.ejs', {alertMessage: "Preference updated. Stopped receiving daily shipment reports."});
   }
function order_tracking_system_yesHandler(request, response) {
   response.render(__dirname + '/pages/order_tracking.ejs', {alertMessage: "Preference updated. Receiving daily shipment reports."});
   }
async function authenticate (req, response){
   try{
      employeeID = req.body.username
      employeePassword = req.body.password
      let userEmployee = await database.findEmployee(employeeID,employeePassword)
      if (userEmployee.employee_password == employeePassword){
         currentName = userEmployee.employee_name
         sessionEmployeeID = userEmployee.employee_id
         response.render(__dirname + '/pages/control_panel.ejs', {currentName: currentName})
         }
      else
      response.render(__dirname + '/pages/login.ejs', {errorMessage: "Incorrect Employee ID or Password."});
   }
   catch{
      response.render(__dirname + '/pages/login.ejs', {errorMessage: "Incorrect Employee ID or Password."});
   }
}

// ROUTING
app.get('/', indexHandler);
app.post('/control_panel', control_panelHandler);
app.post('/authenticate', authenticate);

// SHIPMENT MANAGEMENT ROUTING
app.post('/shipment_management', shipment_managementHandler);

app.post('/add_shipment', function(req,res) {
   var shipment_id = req.body.add_shipment_id
   var shipment_date = req.body.add_shipment_date
   var shipment_quantity = req.body.add_shipment_quantity
   var order_id = req.body.add_order_id
   var employee_id = req.body.add_employee_id
   if (shipment_id != null){database.addShipment(shipment_id, shipment_date, shipment_quantity,order_id,employee_id)}
   shipment_id = null
   res.redirect(307,'/shipment_management')
});

app.post('/delete_shipment', function(req,res) {
   var shipment_id = req.body.delete_shipment_id
   if (shipment_id != null){database.removeShipment(shipment_id)}
   shipment_id = null
   res.redirect(307,'/shipment_management')
});

app.post('/update_shipment', function(req,res) {
   var shipment_id = req.body.update_shipment_id
   var shipment_date = req.body.update_shipment_date
   var shipment_quantity = req.body.update_shipment_quantity
   var order_id = req.body.update_order_id
   var employee_id = req.body.update_employee_id
   if (shipment_id != null){database.updateShipment(shipment_id, shipment_date, shipment_quantity,order_id,employee_id)}
   shipment_id = null
   res.redirect(307,'/shipment_management')
});
app.post('/view_shipments', database.viewShipments);

// CUSTOMER MANAGEMENT ROUTING
app.post('/customer_management', customer_managementHandler);
app.post('/add_customer', function(req,res) {
   var customer_id = req.body.add_customer_id
   var customer_name = req.body.add_customer_name
   var customer_email = req.body.add_customer_email
   var customer_phone = req.body.add_customer_phone
   var customer_address = req.body.add_customer_address
   if (customer_id != null){database.addCustomer(customer_id, customer_name, customer_email,customer_phone,customer_address)}
   customer_id = null
   res.redirect(307,'/customer_management')
});

app.post('/delete_customer', function(req,res) {
   var customer_id = req.body.delete_customer_id
   if (customer_id != null){database.removeCustomer(customer_id)}
   customer_id = null
   res.redirect(307,'/customer_management')
});

app.post('/update_customer', function(req,res) {
   var customer_id = req.body.update_customer_id
   var customer_name = req.body.update_customer_name
   var customer_email = req.body.update_customer_email
   var customer_phone = req.body.update_customer_phone
   var customer_address = req.body.update_customer_address
   if (customer_id != null){database.updateCustomer(customer_id, customer_name, customer_email,customer_phone,customer_address)}
   customer_id = null
   res.redirect(307,'/customer_management')
});
app.post('/view_customers', database.viewCustomers);

// STOCK MANAGEMENT ROUTING
app.post('/stock_management', stock_managementHandler);
app.post('/add_product', function(req,res) {
   var product_id = req.body.add_product_id
   var product_name = req.body.add_product_name
   var product_price = req.body.add_product_price
   var product_quantity = req.body.add_product_quantity
   var product_category = req.body.add_product_category
   var product_expirydate = req.body.add_product_expirydate
   if (product_id != null){database.addProduct(product_id, product_name, product_price,product_quantity,product_category,product_expirydate)}
   product_id = null
   res.redirect(307,'/stock_management')
});

app.post('/delete_product', function(req,res) {
   var product_id = req.body.delete_product_id
   if (product_id != null){database.removeProduct(product_id)}
   product_id = null
   res.redirect(307,'/stock_management')
});

app.post('/update_product', function(req,res) {
   var product_id = req.body.update_product_id
   var product_name = req.body.update_product_name
   var product_price = req.body.update_product_price
   var product_quantity = req.body.update_product_quantity
   var product_category = req.body.update_product_category
   var product_expirydate = req.body.update_product_expirydate
   if (product_id != null){database.updateProduct(product_id, product_name, product_price,product_quantity,product_category,product_expirydate)}
   product_id = null
   res.redirect(307,'/stock_management')
});
//loads view for product
app.post('/view_products', database.viewProducts);

// ORDER MANAGEMENT ROUTING
app.post('/order_management', order_managementHandler);
app.post('/add_order', function(req,res) {
   var order_id = req.body.add_order_id
   var product_id = req.body.add_product_id
   var customer_id = req.body.add_customer_id
   var order_status = req.body.add_order_status
   var order_quantity = req.body.add_order_quantity
   if (order_id != null){database.addOrder(order_id, product_id, customer_id,order_status,order_quantity)}
   order_id = null
   res.redirect(307,'/order_management')
});

app.post('/delete_order', function(req,res) {
   var order_id = req.body.delete_order_id
   if (order_id != null){database.removeOrder(order_id)}
   order_id = null
   res.redirect(307,'/order_management')
});

app.post('/update_order', function(req,res) {
   var order_id = req.body.update_order_id
   var product_id = req.body.update_product_id
   var customer_id = req.body.update_customer_id
   var order_status = req.body.update_order_status
   var order_quantity = req.body.update_order_q
   if (order_id != null){database.updateOrder(order_id, product_id, customer_id,order_status,order_quantity)}
   order_id = null
   res.redirect(307,'/order_management')
});

app.post('/view_orders', database.viewOrders);

// USER MANAGEMENT ROUTING
app.post('/user_management', user_managementHandler);
app.post('/add_employee', function(req,res) {
   var employee_id = req.body.add_employee_id
   var employee_password = req.body.add_employee_password
   var employee_name = req.body.add_employee_name
   var employee_email = req.body.add_employee_email
   var employee_address = req.body.add_employee_address
   if (employee_id != null){database.addEmployee(employee_id, employee_password, employee_name,employee_email,employee_address)}
   employee_id = null
   res.redirect(307,'/user_management')
});

app.post('/delete_employee', function(req,res) {
   var employee_id = req.body.delete_employee_id
   if (employee_id != null){database.removeEmployee(employee_id)}
   employee_id = null
   res.redirect(307,'/user_management')
});

app.post('/update_employee', function(req,res) {
   var employee_id = req.body.update_employee_id
   var employee_password = req.body.update_employee_password
   var employee_name = req.body.update_employee_name
   var employee_email = req.body.update_employee_email
   var employee_address = req.body.update_employee_address
   if (employee_id != null){database.updateEmployee(employee_id, employee_password, employee_name,employee_email,employee_address)}
   employee_id = null
   res.redirect(307,'/user_management')
});
app.post('/view_employees', database.viewEmployees);

app.post('/stock_tracking_system', stock_tracking_systemHandler);
app.post('/stock_tracking_system_yes', stock_tracking_system_yesHandler);
app.post('/stock_tracking_system_no', stock_tracking_system_noHandler);
app.post('/stock_tracking_system_report', stock_tracking_system_reportHandler);
app.post('/order_tracking_system', order_tracking_systemHandler);
app.post('/order_tracking_system_report', order_tracking_system_reportHandler);
app.post('/order_tracking_system_yes', order_tracking_system_yesHandler);
app.post('/order_tracking_system_no', order_tracking_system_noHandler);


app.get('*', function(req, res) {
   res.redirect('/');
});