const express = require('express');
const mongoose = require('mongoose');
const app = express();
app.use(express.json());

//Add mongoDB connection
mongoose.set('useUnifiedTopology', true);
const connect_url = "mongodb+srv://admin:admin@warehouse.1erbc.mongodb.net/warehouseDB?retryWrites=true&w=majority"
mongoose.connect(connect_url, { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true });
const db = mongoose.connection
db.once('open', () => {
console.log("MongoDB Connected")
})

//Defining schemas
const CustomerSchema = mongoose.Schema({ 
  customer_id: { type: Number, required: true},
  customer_name: String,
  customer_email: String,
  customer_phone: Number,
  customer_address: String
});
const ProductSchema = mongoose.Schema({
  product_id: { type: Number, required: true},
  product_name: String,
  product_price: Number,
  product_quantity: Number,
  product_category: String,
  product_expirydate: Date,
});
const OrderSchema = mongoose.Schema({
  order_id: { type: Number, required: true},
  product_id: Number,
  customer_id: Number,
  order_status: String,
  order_date: Date,
  order_quantity: Number
});
const ShipmentSchema = mongoose.Schema({
  shipment_id: { type: Number, required: true},
  shipment_date: Date,
  shipment_quantity: Number,
  order_id: Number,
  employee_id: Number
});
const EmployeeSchema = mongoose.Schema({ 
  employee_id: { type: Number, required: true}, 
  employee_password: String,
  employee_name: String,
  employee_email: String,
  employee_phone: Number,
  employee_address: String
});

//Making models from Schemas
const Customer = mongoose.model('Customer', CustomerSchema, 'Customer');
const Product = mongoose.model('Product', ProductSchema, 'Product');
const Order = mongoose.model('Order', OrderSchema, 'Order');
const Shipment = mongoose.model('Shipment', ShipmentSchema, 'Shipment');
const Employee = mongoose.model('Employee', EmployeeSchema, 'Employee');

// ALL CRUD FUNCTIONALITY BELOW
//Customer CRUD
function addCustomer(customer_id, customer_name, customer_email, customer_phone, customer_address){
  try{
    const newCustomer = new Customer({
      customer_id: customer_id,
      customer_name: customer_name,
      customer_email: customer_email,
      customer_phone: customer_phone,
      customer_address: customer_address
    });
    newCustomer.save(function (err, newCustomer) {
      if(err){
        console.log("Error performing CRUD function - validation error.")}
      else{
        console.log('Saved to Customer collection' + newCustomer)}
      })}
  catch(err){console.log("Error performing DB function. " + err)}
  }

function removeCustomer (customer_id){
  try{
    Customer.findOneAndDelete({customer_id: customer_id}, function (err) { 
      if(err){
        console.log("Error performing CRUD function - validation error.")}
      else{
        console.log('Removed DB entry.')}
      })} 
  catch(err){console.log("Error performing DB function. " + err)}
  };

function updateCustomer (customer_id, customer_name, customer_email, customer_phone, customer_address){
  try{
  const update = {customer_id: customer_id, customer_name: customer_name,customer_email: customer_email,customer_phone: customer_phone, customer_address: customer_address}
  Customer.findOneAndUpdate({customer_id: customer_id},update,{new: true}, function (err) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Updated DB entry.')}
    })} 
  catch(err){console.log("Error performing DB function. " + err)}
  }

async function viewCustomers   (){
  let data = await Customer.find()
  return data
    }

//Product CRUD
function addProduct(product_id, product_name, product_price, product_quantity, product_category, product_expirydate){
  try{
  const newProduct = new Product({
    product_id: product_id,
    product_name: product_name,
    product_price: product_price,
    product_quantity: product_quantity,
    product_category: product_category,
    product_expirydate: product_expirydate
  });
  newProduct.save(function (err, newProduct) {
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Saved to collection' + newProduct)}
    })}
  catch(err){console.log("Error performing DB function. " + err)}
  }

function removeProduct (product_id){
  try{
    Product.findOneAndDelete({product_id: product_id}, function (err) { 
      if(err){
        console.log("Error performing CRUD function - validation error.")}
      else{
        console.log('Removed DB entry.')}
      })} 
  catch(err){console.log("Error performing DB function. " + err)}
  }

function updateProduct (product_id, product_name, product_price, product_quantity, product_category, product_expirydate){
  try{
  const update = {product_id: product_id, product_name:product_name, product_price:product_price, product_quantity:product_quantity, product_category:product_category,product_expirydate:product_expirydate}
  Product.findOneAndUpdate({product_id: product_id},update,{new: true}, function (err, docs) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Updated DB entry.')}
    })} 
  catch(err){console.log("Error performing DB function. " + err)}
  }

async function viewProducts (){
  let data = await Product.find()
  return data
    } 

//Order CRUD
function addOrder(order_id, product_id, customer_id, order_status, order_quantity){
  try{
  const newOrder = new Order({
    order_id: order_id,
    product_id: product_id,
    customer_id: customer_id,
    order_status: order_status,
    order_date: Date(),
    order_quantity: order_quantity
  });
  newOrder.save(function (err, newOrder) {
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Saved to collection' + newOrder)}
    })}   
  catch(err){console.log("Error performing DB function. " + err)}
  }
    
function removeOrder (order_id){
  try{
  Order.findOneAndDelete({order_id: order_id}, function (err) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Removed DB entry.')}
    })}
  catch(err){console.log("Error performing DB function. " + err)}
  }
  
function updateOrder (order_id, product_id, customer_id, order_status, order_date, order_quantity){
  try{
    const update = {order_id: order_id, product_id:product_id, customer_id:customer_id, order_status:order_status, order_date: order_date, order_quantity: order_quantity}
    Order.findOneAndUpdate({order_id: order_id},update,{new: true}, function (err) { 
      if(err){
        console.log("Error performing CRUD function - validation error.")}
      else{
        console.log('Updated DB entry.')}
      })} 
  catch(err){console.log("Error performing DB function. " + err)}
  }

async function viewOrders (){
  let data = await Order.find()
  return data
    }

//Shipment CRUD

function addShipment(shipment_id, shipment_date, shipment_quantity, order_id, employee_id){
  try{
    const newShipment = new Shipment({
      shipment_id: shipment_id,
      shipment_date: shipment_date,
      shipment_quantity: shipment_quantity,
      order_id: order_id,
      employee_id: employee_id
      });
      newShipment.save(function (err, newShipment) {
        if(err){
          console.log("Error performing CRUD function - validation error.")}
        else{
          console.log('Saved to collection' + newShipment)}
        })}
  catch(err){console.log("Error performing DB function. " + err)}
}

function removeShipment (shipment_id){
  try{
  Shipment.findOneAndDelete({shipment_id: shipment_id}, function (err) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Removed DB entry.')}
    })}
    catch(err){console.log("Error performing DB function. " + err)}
  }

function updateShipment (shipment_id, shipment_date, shipment_quantity, order_id, employee_id){
  try{
  const update = {shipment_id: shipment_id, shipment_date: shipment_date, shipment_quantity: shipment_quantity, order_id: order_id, employee_id:employee_id}
  Shipment.findOneAndUpdate({shipment_id: shipment_id},update,{new: true}, function (err) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Updated DB entry.')}
    })} 
  catch(err){console.log("Error performing DB function. " + err)}
}

async function viewShipments (){
  let data = await Shipment.find()
  return data
}

//Employee CRUD
function addEmployee(employee_id, employee_password, employee_name, employee_email, employee_address){
  try{
    const newEmployee = new Employee({
      employee_id: employee_id, 
      employee_password: employee_password,
      employee_name: employee_name,
      employee_email: employee_email,
      employee_address: employee_address
    });
    newEmployee.save(function (err, newEmployee) {
      if(err){
        console.log("Error performing CRUD function - validation error.")}
      else{
        console.log('Saved to collection' + newEmployee)}
      })}
  catch(err){console.log("Error performing DB function. " + err)}
}
  
function removeEmployee (employee_id){
  try{
  Employee.findOneAndDelete({employee_id: employee_id}, function (err, docs) { 
    if (err){ 
        console.log(err) 
    } 
    else{ 
        console.log("Deleted: ", docs); 
    }})}  
  catch(err){console.log("Error performing DB function. " + err)}
}

function updateEmployee (employee_id, employee_password, employee_name, employee_email, employee_address){
  try{
  const update = {employee_id: employee_id, employee_password: employee_password, employee_name: employee_name,employee_email: employee_email, employee_address: employee_address}
  Employee.findOneAndUpdate({employee_id: employee_id},update,{new: true}, function (err) { 
    if(err){
      console.log("Error performing CRUD function - validation error.")}
    else{
      console.log('Updated DB entry.')}
    })} 
  catch(err){console.log("Error performing DB function. " + err)}
}

async function viewEmployees (){
  let data = await Employee.find()
  return data
}

//authenticate
async function findEmployee (givenID){
    let userEmployee = await Employee.findOne({employee_id: givenID})
    return userEmployee
}
  
//check for low stock
async function lowStock(){
  let lowStockItems = await Product.find({product_quantity: { $lt: 50 }})
  return lowStockItems
}

//check for no stock
async function noStock(){
  let noStockItems = await Product.find({product_quantity: { $lt: 1 }})
  return noStockItems
}

//check for expiring stock
async function expiringStock(){
  const date = new Date()
  date.setDate(date.getDate()+7)
  let expiringItems = await Product.find({product_expirydate: { $lt: date, $gt: Date()}})
  return expiringItems
}

async function shipmentsToday(){
  const date1 = new Date()
  const date2 = new Date()
  date1.setDate(date1.getDate() - 1)
  date2.setDate(date2.getDate() + 1)
  var yesterdayDate = new Date(date1.toISOString());
  var tomorrowDate = new Date(date2.toISOString());
  let shipments = await Shipment.find({shipment_date: { $lte: tomorrowDate, $gte: yesterdayDate}})
  return shipments
}


module.exports = {addCustomer, addProduct, addOrder, addShipment, addEmployee, removeCustomer, removeProduct, removeOrder, removeShipment, removeEmployee, updateCustomer, updateProduct, updateOrder, updateShipment, updateEmployee, viewEmployees, viewCustomers, viewOrders, viewProducts, viewShipments, findEmployee, lowStock, noStock, expiringStock, shipmentsToday}
