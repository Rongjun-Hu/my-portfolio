#!/bin/sh
npm install
node index.js